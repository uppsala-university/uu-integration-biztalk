# AtomAdapter
BizTalk AtomAdapter
This BizTalk Adapter reads Atom feeds of archive type. The Adapter makes sure that all entries are read in order.
