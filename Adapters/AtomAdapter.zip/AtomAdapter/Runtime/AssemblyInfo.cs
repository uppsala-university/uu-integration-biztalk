
using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: CLSCompliant(false)]

// General attributes:

[assembly: AssemblyTitle("BizTalk Adapter for Atom feeds")]
[assembly: AssemblyDescription("Adapter for archive typed atom feeds")]
[assembly: AssemblyCulture("")]




